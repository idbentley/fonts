BELLIGERANT MADNESSA true type font by P.D. Magnuswww.fontmonkey.com

LICENSE

This font is copyright 2008 by P.D. Magnus. Like all the Fontmonkey fonts, it is free for for all commercial or non-commercial use.
To be clear: They do not cost anything.

If you do use them for something, though, I would love to here about it.
I would appreciate a sample of the thing for which you used the font, a
photo of it, or even just an e-mail telling me about it.

You can contact me via the website or by e-mail at pmagnus<at>fecundity.com

You are also encouraged to acknowledge fontmonkey or link to me, although
neither is strictly speaking required.

The font files may be freely distributed provided this license,
attribution to me, and the fontmonkey URL are included.

VERSION HISTORY

26apr2008 first release
